const notFound = (req,res) => res.status(404).send("Route Does not exist");


export default notFound;