const allowedOrigins = [
    'https://lighte-ticket.com',
    'http://localhost:3000'
]

export default allowedOrigins